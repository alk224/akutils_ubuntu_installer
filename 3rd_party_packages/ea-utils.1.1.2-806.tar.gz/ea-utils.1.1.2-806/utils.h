#include <string>
#include <vector>

std::string string_format(const std::string &fmt, ...);
std::vector<char *> split(char* str, const char* delim);
