.. _install_index:

============================
Installing Primer Prospector
============================

.. toctree::
   :maxdepth: 1
   :glob:

   ./*


