.. _index:

=========================
Primer Prospector scripts
=========================

.. toctree::
   :maxdepth: 1
   :glob:

   ./*


