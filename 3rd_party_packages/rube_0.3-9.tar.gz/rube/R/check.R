check <- function(x, ...) {
  UseMethod("check")
}

