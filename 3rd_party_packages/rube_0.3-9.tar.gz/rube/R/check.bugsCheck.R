check.bugsCheck <- function(x, ...) {
  print(x)
}

