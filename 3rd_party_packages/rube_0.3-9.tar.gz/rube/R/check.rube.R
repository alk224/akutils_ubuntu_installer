check.rube <- function(x, ...) {
  print(x$check)
}

