model <- function(x, ..., indent="  ", lineNumbers=TRUE) {
  UseMethod("model")
}

