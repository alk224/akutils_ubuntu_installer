model.bugsCheck <- function(x, ..., indent="  ", lineNumbers=TRUE) {
  showModel(x$model, indent=indent, lineNumbers=lineNumbers)
}

