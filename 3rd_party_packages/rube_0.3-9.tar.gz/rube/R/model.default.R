model.default <- function(x, ..., indent="  ", lineNumbers=TRUE) {
  stop("method 'model()' is not defined for class '", class(x), "'")
}


