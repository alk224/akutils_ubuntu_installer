model.rube <- function(x, ..., indent="  ", lineNumbers=TRUE) {
  showModel(x$check$model, indent=indent, lineNumbers=lineNumbers)
}

