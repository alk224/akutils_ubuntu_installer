#!/bin/bash

cat > prova.mail
